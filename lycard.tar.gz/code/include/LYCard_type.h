

#ifndef LYCARD_TYPE
#define LYCARD_TYPE
typedef int bool;
typedef unsigned char u8;
#endif
