//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by mwic_rd.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MWIC_RD_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       129
#define IDC_LIST1                       1000
#define ID_MENUITEMEXIT                 32771
#define ID_MENUITEM24C01A               32772
#define ID_MENUITEMCONN                 32773
#define ID_MENUITEM24c02                32774
#define ID_MENUITEM24c04                32775
#define ID_MENUITEM24c08                32776
#define ID_MENUITEM24c16                32777
#define ID_MENUITEM24c64                32778
#define ID_MENUITEM4442                 32779
#define ID_MENUITEMcpu                  32780
#define ID_MENUITEMSamCard              32783
#define DES                             65535

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
